using System;
using System.IO;
using System.Text;
using Bedrock.Logging;
using Xunit;

namespace Bedrock.Tests.Logging
{
    public class TextLoggerFixture
    {
        [Fact]
        public void NullTextWriterThrows()
        {
            Assert.Throws<ArgumentNullException>(()=> { ILoggerFacade logger = new TextLogger(null); });
        }

        [Fact]
        public void ShouldWriteToTextWriter()
        {
            TextWriter writer = new StringWriter();
            ILoggerFacade logger = new TextLogger(writer);

            logger.Log("Test", Category.Debug, Priority.Low);
            Assert.Contains(writer.ToString(), "Test");
            Assert.Contains(writer.ToString(), "DEBUG");
            Assert.Contains(writer.ToString(), "Low");
        }

        [Fact]
        public void ShouldDisposeWriterOnDispose()
        {
            MockWriter writer = new MockWriter();
            IDisposable logger = new TextLogger(writer);

            Assert.False(writer.DisposeCalled);
            logger.Dispose();
            Assert.True(writer.DisposeCalled);
        }
    }

    internal class MockWriter : TextWriter
    {
        public bool DisposeCalled;
        public override Encoding Encoding
        {
            get { throw new NotImplementedException(); }
        }

        protected override void Dispose(bool disposing)
        {
            DisposeCalled = true;
            base.Dispose(disposing);
        }
    }
}